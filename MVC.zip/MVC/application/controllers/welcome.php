<?php

class welcome {

   public function index(){
       echo "welcome controller";
   }

}



?>