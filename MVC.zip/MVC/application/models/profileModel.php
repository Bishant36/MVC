<?php 

class profileModel extends database {


    public function getData($userId){

        if($this->Query("SELECT * FROM fruit WHERE userId = ? ", [$userId])){

            $data = $this->fetchAll();
            return $data;

        }

    }

    public function edit_data($id, $userId){

        if($this->Query("SELECT * FROM fruit WHERE id = ? && userId = ? ", [$id, $userId])){

            $row = $this->fetch();
            return $row;

        }

    }


}


?>