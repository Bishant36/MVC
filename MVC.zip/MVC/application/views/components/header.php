<?php linkCSS("assets/css/bootstrap.min.css"); ?>
<?php linkCSS("assets/css/style.css") ?>