<?php $this->flash('fruitAdded', 'alert alert-success');  ?>
<?php $this->flash('fruitUpdated', 'alert alert-success'); ?>
<?php $this->flash('deleted', 'alert alert-success'); ?>