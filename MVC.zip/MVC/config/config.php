
<?php

// Database configurations 

define("HOST", "localhost");
define("USER", "root");
define("DATABASE", "mvc");
define("PASSWORD", "");

// Base URL

define("BASEURL", "http://localhost/MVCFramework");

?>
